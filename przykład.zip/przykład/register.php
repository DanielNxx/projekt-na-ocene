<?php

$nazwa = $_POST['nazwa'];
$email = $_POST['email'];
$haslo = $_POST['haslo'];

$connection = new_mysqli('localhost','root','','baza');

if (mysqli_connect_errno()){
    echo "Failed to connect to MySQL: " . mysqli_connect_error();
}
else{
    $sql = "INSERT INTO dane_uzytkownika VALUES ('$nazwa',
    '$email','$haslo')";
    if(mysqli_query($connection, $sql)){
        echo "<h3>Dane pomyślnie dodane do bazy.</h3>";
    } else{
        echo "ERROR" . mysqli_error($connection);
    }
    mysqli_close($connection);
}
?>