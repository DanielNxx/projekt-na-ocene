<?php
$connection = newmysqli('localhost','root','','baza');
//po sprawdzeniu konta ma dać użykoniku cookies na że jest zalogowany do wylogowania lub upłyniecia 24 godzin
//Jak jest zalogowany to ma dostać się na strone index_login.html
?>